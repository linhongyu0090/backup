//
//  AdministratorTBC.swift
//  san_zhuang_quan_zhan
//
//  Created by 林宏宇 on 2022/4/11.
//
//
import UIKit
import SwiftUI

class AdministratorTBC: UITabBarController,UITabBarControllerDelegate{
    private var productListNC:UINavigationController!
    private var productListVC:ProductListVC!
    private var examineNC:UINavigationController!
    private var examineVC:ExamineVC!
//    private var examineDoneVC:ExamineDoneVC!
    private var conductNC:UINavigationController!
    private var conductVC:ConductVC!
    private var mineNC:UINavigationController!
    private var mineVC:MineVC!


    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self

        productListVC = ProductListVC()
        productListVC.title = "商品"
        productListVC.tabBarItem.image = UIImage(named: "bag")
        productListVC.tabBarItem.selectedImage = UIImage(named:"bag")
        productListVC.tabBarItem.badgeValue = "TOP"
//        productListVC.tabBarItem.imageInsets = UIEdgeInsets(top: 6, left: 0, bottom: -6, right: 0)
        productListNC = UINavigationController(rootViewController: productListVC)

        examineVC = ExamineVC()
        examineVC.title = "审核"
        examineVC.tabBarItem.image = UIImage(named: "sh")
        examineVC.tabBarItem.selectedImage = UIImage(named: "sh")
//        examineDoneVC()
        examineNC = UINavigationController(rootViewController: examineVC)

        conductVC = ConductVC()
        conductVC.title = "处理"
        conductVC.tabBarItem.image = UIImage(named: "conduct")
        conductVC.tabBarItem.selectedImage = UIImage(named: "conduct")
        conductNC = UINavigationController(rootViewController: conductVC)

        mineVC = MineVC()
        mineVC.title = "我的"
//        mineVC.tabBarItem.image = UIImage(systemName: "house")
        mineVC.tabBarItem.image = UIImage(named: "my")
//        mineVC.tabBarItem.selectedImage = UIImage(systemName: "house")
        mineVC.tabBarItem.selectedImage = UIImage(named: "my")
//        mineVC.tabBarItem.imageInsets = UIEdgeInsets(top: 6, left: 0, bottom: -6, right: 0)
//        mineVC.tabBarItem.image?.images.
        mineNC = UINavigationController(rootViewController: mineVC)


//        tabBar.tintColor = .systemOrange
        tabBar.tintColor = UIColor(named: "wechat")
        tabBar.contentMode = .scaleAspectFit
//        tabBar.contentMode = .scaleToFill

        let tabbarAppearance = UITabBarAppearance()
        tabbarAppearance.configureWithDefaultBackground()

        let tabbarItemAppearance = UITabBarItemAppearance()
        tabbarItemAppearance.normal.iconColor = .label
        tabbarItemAppearance.normal.titleTextAttributes = [
            NSAttributedString.Key.foregroundColor:UIColor.label,
            NSAttributedString.Key.font:UIFont.systemFont(ofSize: 11,weight: .light)
        ]
        tabbarItemAppearance.selected.titleTextAttributes = [
            NSAttributedString.Key.font:UIFont.systemFont(ofSize: 11,weight: .light)
        ]

        tabbarAppearance.stackedLayoutAppearance = tabbarItemAppearance
        tabBar.standardAppearance = tabbarAppearance
        tabBar.scrollEdgeAppearance = tabbarAppearance

        viewControllers = [productListNC,examineNC,conductNC,mineNC]

        // Do any additional setup after loading the view.
    }
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        let items = tabBar.items!
        let itemNames = ["购物","审核","处理","我的"]
        let homeTabbarItem = items[0]
        let myTabbarItem = items[3]
        let index = tabBar.items!.firstIndex(of: item)!
        if(index == 0){
            homeTabbarItem.title = nil
//            mineVC.tabBarItem.imageInsets = UIEdgeInsets(top: 6, left: 0, bottom: -6, right: 0)
            homeTabbarItem.badgeColor = .systemRed
        }else{
            homeTabbarItem.title = itemNames[0]
            homeTabbarItem.imageInsets = .zero
        }
//        if(index == 3){
//            myTabbarItem.title = nil
//            mineVC.tabBarItem.image
//            mineVC.tabBarItem.imageInsets = UIEdgeInsets(top: 6, left: 0, bottom: -6, right: 0)
//        }else{
//            myTabbarItem.title = itemNames[3]
//            myTabbarItem.imageInsets = .zero
//        }

    }
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {

    }
}
