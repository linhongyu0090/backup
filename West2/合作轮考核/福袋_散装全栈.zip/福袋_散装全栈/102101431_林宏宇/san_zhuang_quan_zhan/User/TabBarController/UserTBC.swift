//
//  UserTBC.swift
//  san_zhuang_quan_zhan
//
//  Created by 林宏宇 on 2022/5/6.
//

//import UIKit
//
//class UserTBC: UITabBarController {
//
//    private var productListNC:UINavigationController!
//    private var productListVC:ProductListVC!
//    private var uploadProductNC:UINavigationController!
//    private var uploadProductVC:UploadProductVC!
//    private var orderNC:UINavigationController!
//    private var orderVC:OrderVC!
//    private var mineNC:UINavigationController!
//    private var mineVC:MineVC!
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        productListVC = ProductListVC()
//        productListVC.title = "商品"
//        productListVC.tabBarItem.image = UIImage(systemName: "bag")
//        productListVC.tabBarItem.selectedImage = UIImage(named: "bag.fill")
//        productListVC.tabBarItem.badgeValue = "TOP"
//        productListVC.tabBarItem.imageInsets = UIEdgeInsets(top: 6, left: 0, bottom: -6, right: 0)
//        productListNC = UINavigationController(rootViewController: productListVC)
//
//
//        uploadProductVC = UploadProductVC()
//        uploadProductVC.title = "上传"
//        uploadProductVC.tabBarItem.image = UIImage(systemName: "pencil.circle")
//        uploadProductVC.tabBarItem.selectedImage = UIImage(systemName: "pencil.circle")
//        uploadProductNC = UINavigationController(rootViewController: uploadProductVC)
//
//        orderVC = OrderVC()
//        orderVC.title = "订单"
//        orderVC.tabBarItem.image = UIImage(systemName: "bag")
//        orderVC.tabBarItem.selectedImage = UIImage(systemName: "bag.fill")
//        orderNC = UINavigationController(rootViewController: orderVC)
//
//        mineVC = MineVC()
//        mineVC.title = "我的"
//        mineVC.tabBarItem.image = UIImage(systemName: "house")
//        mineVC.tabBarItem.selectedImage = UIImage(systemName: "house")
//        mineNC = UINavigationController(rootViewController: mineVC)
//
//        viewControllers = [productListNC,uploadProductNC,orderNC,mineNC]
//
//    }
//
//}
import UIKit

class UserTBC: UITabBarController, UITabBarControllerDelegate, CustomTabBarDelegate {
    
    var customTabBar1 = CustomTabBar()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
        let customTabBar = CustomTabBar()
        // 取消tabBar的透明效果
        customTabBar.isTranslucent = false
        // 设置tabBar的代理
        customTabBar.myDelegate = self
        self.customTabBar1 = customTabBar
        self.setValue(customTabBar, forKey: "tabBar")
        
        self.customTabBar1.datePickBlock = {str in
            print(str)
        }
        self.customTabBar1.dictDataBlock = { dict in
            print(dict)
        }
        
        self.setUpTabBar()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    // MARK: - 控制器的信息
    func setUpTabBar() {
        
        let demo1VC  = ProductListVC()
        let demo2VC  = OrderVC()
        
        creatTabbarView(viewController: demo1VC, image: "home_normal", selectImage: "home_highlight", title: "商品", tag: 1)
        creatTabbarView(viewController: demo2VC, image: "mycity_normal", selectImage: "mycity_highlight", title: "订单", tag: 2)
        
        self.tabBar.tintColor = UIColor(red: 255/255.0, green: 204/255.0, blue: 13/255.0, alpha: 1)
        self.tabBar.isTranslucent = false
        
        self.viewControllers = [
            UINavigationController(rootViewController: demo1VC),
            UINavigationController(rootViewController: demo2VC),
        ];
        
        self.delegate = self
    }
    
    // MARK: - TabBar里面的文字图片
    func creatTabbarView(viewController:UIViewController, image:NSString, selectImage:NSString, title:NSString, tag:NSInteger) {
        // alwaysOriginal 始终绘制图片原始状态，不使用Tint Color。
        viewController.tabBarItem.image = UIImage(named: image as String)?.withRenderingMode(.alwaysOriginal)
        viewController.tabBarItem.selectedImage = UIImage(named: selectImage as String)?.withRenderingMode(.alwaysOriginal)
        viewController.title = title as String
        viewController.tabBarItem.tag = tag
    }
    
    // MARK: - UITabBarControllerDelegate
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {

        self.customTabBar1.plusButton.isSelected = false

        return true
    }
    
    // MARK: -- CustomTabBarDelegate
    func tabBarDidClickPlusButton() {
        /**
         definesPresentationContext这一属性决定了那个父控制器的View，
         将会以优先于UIModalPresentationCurrentContext这种呈现方式来展现自己的View。
         如果没有父控制器设置这一属性，那么展示的控制器将会是根视图控制器

         modalPresentationStyle可以设置模态是否隐藏

         */
        self.customTabBar1.plusButton.isSelected = true
        
        let vc = UploadProductVC()
        self.definesPresentationContext = true
//        vc.view.backgroundColor = UIColor.clear
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
    
}
