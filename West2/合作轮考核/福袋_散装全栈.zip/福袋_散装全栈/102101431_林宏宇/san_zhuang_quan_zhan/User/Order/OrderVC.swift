//
//  OrderVC.swift
//  san_zhuang_quan_zhan
//
//  Created by 林宏宇 on 2022/5/6.
//

import UIKit
import MJRefresh

class OrderVC: UIViewController {
    var tableView:UITableView!
    var list:[Product] = []
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = 250
        tableView.separatorStyle = .none
        tableView.register(OrderCell.self, forCellReuseIdentifier: OrderCell.description())
        self.view.addSubview(tableView)
        
        tableView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.bottom.equalToSuperview()
            make.right.equalToSuperview()
            make.left.equalToSuperview()
        }
        
        let header = MJRefreshNormalHeader{
            self.refreshData()
        }
        header.lastUpdatedTimeLabel?.isHidden = true
        header.stateLabel?.isHidden = true
        tableView.mj_header = header
        // Do any additional setup after loading the view.
        

    }
    func refreshData(){
        NetworkAPI.homeProductList { result in
            self.tableView.mj_header?.endRefreshing()
            switch result{
            case let.success(list):
                self.list = list
                self.tableView.reloadData()
            case let.failure(error):
                print("error")
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension OrderVC:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var product:Product
        product = list[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: OrderCell.description(), for: indexPath) as! OrderCell
        cell.setName(product.name)
        cell.setPrice(product.price)
        cell.setCollect(true)
        cell.setRating(product.rating)
        cell.setTradeName(product.tradename)
        cell.setCover(" ")
        cell.setCategroy(product.category)
        return cell
    }
}
extension OrderVC:UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let product = list[indexPath.row]
        let productDetailVC = ProductDetailVC(product: product)
        self.navigationController?.pushViewController(productDetailVC, animated: true)
    }
}
