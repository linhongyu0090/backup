//
//  UploadView.swift
//  san_zhuang_quan_zhan
//
//  Created by 林宏宇 on 2022/5/16.
//

import UIKit
import SnapKit

class UploadView: UIView {
    var numberOfRows:Int{
        get{_number}
        set{_number = min(max(newValue,0),10)}
    }
    private var _number:Int = 0{
        didSet{
            for(_,textFielld) in textFields.enumerated(){
                textFielld.isHidden = false
            }
        }
    }
    private var textFields:[UITextField] = []
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        isUserInteractionEnabled = true
        
        for _ in 0...6{
            let textField = UITextField()
            textField.snp.makeConstraints { make in
                make.height.equalTo(50)
            }
            Utilities.styleTextField(textField).self
            textField.text = "请输入"
            textField.textColor = .systemOrange
            textField.font = .systemFont(ofSize: 25)
            textFields.append(textField)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
