//
//  UploadProductVC.swift
//  san_zhuang_quan_zhan
//
//  Created by 林宏宇 on 2022/5/6.
//

import UIKit

class UploadProductVC: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
        let text = UploadView()
        text.numberOfRows = 6
        self.view.addSubview(text)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
